# -*- coding: utf-8 -*-
"""
pyQode is a source code editor widget for PyQt4

pyQode is a **namespace package**.
"""
import pkg_resources
pkg_resources.declare_namespace(__name__)
