# -*- coding: utf-8 -*-
"""
This package contains the ui files and their compiled version.

To update ui files, just run compile_ui.py.

"""
