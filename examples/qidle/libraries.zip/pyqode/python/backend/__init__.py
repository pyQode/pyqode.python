# -*- coding: utf-8 -*-
"""
The backend package contains everything needed to implement the
server side of pyqode.

"""
