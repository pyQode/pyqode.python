# -*- coding: utf-8 -*-
"""
This packages contains the qt ui and resource files used in
pyqode.python.

To update an ui/rc file, just run the compile_ui script.

"""
