This archive contains all the libaries used by the backend:
    - pyqode.core
    - pyqode.python
    - jedi
    - frosted
    - pep8


We import them from a zip folder so that we can run the backend with different
interpreters without bothering the user with installing the required 
dependencies for the chosen interpreter (this allow to run all the tools even
with a virtual environment).

