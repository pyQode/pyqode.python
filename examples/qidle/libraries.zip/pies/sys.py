from __future__ import absolute_import

from sys import *

if version_info[0] == 2:
    intern = intern
